# 1. Definir variables
$fileName = "WakeOnLanMonitor.exe"
$installDir = "C:\Program Files\WOL"
$destPath = "$installDir\$fileName"

# El agente de FOG descarga el snapin en su carpeta de ejecución actual
# Buscamos el archivo en la carpeta donde se está ejecutando el script
$currentDir = Get-Location
$sourcePath = Join-Path $currentDir $fileName

# 2. Crear el directorio de destino
if (!(Test-Path $installDir)) {
    New-Item -Path $installDir -ItemType Directory -Force
}

# 3. Mover el archivo si existe (FOG ya lo habrá descargado)
if (Test-Path $sourcePath) {
    Copy-Item -Path $sourcePath -Destination $destPath -Force
    Unblock-File -Path $destPath
} else {
    Write-Error "FOG no descargó el archivo $fileName en $sourcePath"
    exit 1
}

# 4. Crear el acceso directo en el escritorio público
$Shell = New-Object -ComObject WScript.Shell
$PublicDesktop = [System.IO.Path]::Combine($env:Public, "Desktop")
$Shortcut = $Shell.CreateShortcut("$PublicDesktop\Wake On Lan Monitor.lnk")
$Shortcut.TargetPath = $destPath
$Shortcut.WorkingDirectory = $installDir
$Shortcut.Save()

Write-Host "Instalación completada con éxito."