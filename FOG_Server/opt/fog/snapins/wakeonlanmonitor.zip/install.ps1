# Usamos $PSScriptRoot para saber dónde estamos (como dice la doc de FOG)
$currentDir = $PSScriptRoot
$fileName = "WakeOnLanMonitor.exe"
$sourcePath = Join-Path $currentDir $fileName

$installDir = "C:\Program Files\WOL"
$destPath = "$installDir\$fileName"

# 1. Crear directorio de destino
if (!(Test-Path $installDir)) {
    New-Item -Path $installDir -ItemType Directory -Force
}

# 2. Copiar el ejecutable desde la carpeta temporal de FOG a la carpeta final
if (Test-Path $sourcePath) {
    Copy-Item -Path $sourcePath -Destination $destPath -Force
    Unblock-File -Path $destPath
}

# 3. Crear el acceso directo en el escritorio público
$Shell = New-Object -ComObject WScript.Shell
$PublicDesktop = [System.IO.Path]::Combine($env:Public, "Desktop")
$Shortcut = $Shell.CreateShortcut("$PublicDesktop\Wake On Lan Monitor.lnk")
$Shortcut.TargetPath = $destPath
$Shortcut.WorkingDirectory = $installDir
$Shortcut.Save()